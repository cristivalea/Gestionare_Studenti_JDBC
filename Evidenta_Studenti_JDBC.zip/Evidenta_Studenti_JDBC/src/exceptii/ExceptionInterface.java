package exceptii;

public interface ExceptionInterface {
    /**
     *
     * @return
     */
    public String getValue();
}
